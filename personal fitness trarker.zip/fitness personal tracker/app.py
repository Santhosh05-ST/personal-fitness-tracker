import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import time




# Workout Data
workout_data = {
    "1": {
        "title": "Full Body Workout (Strength Focus)",
        "exercises": [
            {"name": "Squats", "sets": 4, "reps": "8-10", "rest": "90 seconds", "explanation": "Stand with your feet shoulder-width apart. Lower your hips back and down, keeping your chest lifted and knees tracking over your toes. Go as deep as you can while maintaining good form, and then drive through your heels to return to standing."},
            {"name": "Bench Press", "sets": 4, "reps": "8-10", "rest": "90 seconds", "explanation": "Lie on a bench, grip the barbell slightly wider than shoulder-width apart. Lower the bar slowly to your chest, then press the bar back up to the starting position, engaging your chest and triceps."},
            {"name": "Bent-Over Rows", "sets": 4, "reps": "8-10", "rest": "90 seconds", "explanation": "Hinge forward from your hips, keeping a slight bend in the knees. Pull the dumbbells (or barbell) toward your torso, squeezing your shoulder blades together at the top of the movement. Lower with control."},
            {"name": "Deadlifts", "sets": 3, "reps": "6-8", "rest": "2 minutes", "explanation": "With your feet shoulder-width apart, grip the bar just outside your knees. Keeping your back flat, push your hips back and lower the bar toward the floor. Engage your hamstrings and glutes to lift the weight back to standing."},
            {"name": "Overhead Press", "sets": 4, "reps": "8-10", "rest": "90 seconds", "explanation": "Stand with your feet shoulder-width apart, holding a barbell or dumbbells at shoulder height. Press the weight overhead, keeping your core tight and avoiding arching your back."},
            {"name": "Plank", "sets": 3, "reps": "45-60 seconds", "rest": "60 seconds", "explanation": "Hold a push-up position, with your elbows directly under your shoulders. Keep your body in a straight line from head to heels and engage your core to avoid sagging your hips."}
        ]
    },
    "2": {
        "title": "Active Recovery / Cardio",
        "exercises": [
            {"name": "Cardio", "explanation": "Go for a light jog, bike ride, or swimming session for 30-40 minutes. This will help improve cardiovascular fitness and promote recovery."}
        ]
    },
    "3": {
        "title": "Full Body Workout (Hypertrophy Focus)",
        "exercises": [
            {"name": "Bulgarian Split Squats", "sets": 4, "reps": "10-12 (each leg)", "rest": "90 seconds", "explanation": "Place one foot on a bench behind you. Lower your hips, keeping your front knee over your ankle. Go as deep as you can while maintaining balance, then press through the heel to return to standing."},
            {"name": "Dumbbell Chest Press", "sets": 4, "reps": "10-12", "rest": "90 seconds", "explanation": "Lie on a bench holding a dumbbell in each hand. Lower the dumbbells toward your chest with your elbows at about 45 degrees. Press them back up by fully extending your arms."},
            {"name": "Lat Pulldowns", "sets": 4, "reps": "10-12", "rest": "90 seconds", "explanation": "Sit at the lat pulldown machine, grip the bar with your hands slightly wider than shoulder-width. Pull the bar down toward your chest, squeezing your shoulder blades together, then slowly return to the starting position."},
            {"name": "Romanian Deadlifts", "sets": 4, "reps": "10-12", "rest": "90 seconds", "explanation": "With your knees slightly bent, hinge at the hips while lowering the barbell (or dumbbells) down your legs, keeping your back straight. Squeeze your glutes and hamstrings to return to standing."},
            {"name": "Dumbbell Lateral Raises", "sets": 3, "reps": "12-15", "rest": "60 seconds", "explanation": "Stand holding a dumbbell in each hand. Raise the dumbbells out to the sides, keeping a slight bend in your elbows. Stop when your arms are parallel to the ground, then lower back down slowly."},
            {"name": "Russian Twists", "sets": 3, "reps": "20-30 twists", "rest": "60 seconds", "explanation": "Sit on the floor with your knees bent and feet off the ground. Hold a weight or medicine ball with both hands, and rotate your torso side to side, engaging your core."}
        ]
    },
    "4": {
        "title": "Active Recovery / Mobility Work",
        "exercises": [
            {"name": "Mobility Work", "explanation": "Focus on stretching, foam rolling, or yoga for 30 minutes to improve flexibility, mobility, and reduce muscle soreness."}
        ]
    },
    "5": {
        "title": "Full Body Workout (Power/Explosive Focus)",
        "exercises": [
            {"name": "Jump Squats", "sets": 4, "reps": "10-12", "rest": "90 seconds", "explanation": "Start with your feet shoulder-width apart. Lower into a squat, then explode upward into a jump. Land softly and immediately go into the next squat."},
            {"name": "Push-Ups", "sets": 4, "reps": "15-20", "rest": "60-90 seconds", "explanation": "Start in a plank position. Lower your chest to the floor, keeping your elbows at a 45-degree angle. Push back up until your arms are fully extended."},
            {"name": "Kettlebell Swings", "sets": 4, "reps": "15-20", "rest": "90 seconds", "explanation": "Hold a kettlebell with both hands. Hinge at your hips, swinging the kettlebell between your legs. Powerfully thrust your hips forward to swing the kettlebell to shoulder height."},
            {"name": "Pull-Ups", "sets": 4, "reps": "As many as possible (AMRAP)", "rest": "90 seconds", "explanation": "Grip a pull-up bar with your palms facing away from you. Pull your body up until your chin is over the bar, then lower back down with control."},
            {"name": "Medicine Ball Slams", "sets": 4, "reps": "12-15", "rest": "90 seconds", "explanation": "Stand holding a medicine ball overhead. Slam the ball down to the floor with power, engaging your core as you do so. Catch the ball and repeat."},
            {"name": "Mountain Climbers", "sets": 3, "reps": "30-45 seconds", "rest": "60 seconds", "explanation": "Start in a push-up position. Bring one knee towards your chest, then quickly switch legs, alternating back and forth in a running motion."}
        ]
    },
    "6": {
        "title": "Active Recovery / Stretching or Light Cardio",
        "exercises": [
            {"name": "Stretching or Light Cardio", "explanation": "Take a brisk walk, swim, or do yoga for 30 minutes to improve recovery and flexibility."}
        ]
    },
    "7": {
        "title": "Rest",
        "exercises": [
            {"name": "Rest", "explanation": "Allow your muscles to recover fully. Focus on hydration, nutrition, and rest."}
        ]
    }
}

# Streamlit UI
st.title("Personal Fitness Tracker")
st.title("Full Body Workout Routine")

# Day selection
day = st.selectbox("Select Day (1-7)", ["1", "2", "3", "4", "5", "6", "7"])

# Display the selected workout details for the chosen day
if day:
    try:
        workout = workout_data.get(day, None)

        if workout:
            st.header(workout["title"])
            for exercise in workout["exercises"]:
                st.subheader(f"Exercise: {exercise['name']}")
                if 'sets' in exercise:
                    st.write(f"**Sets:** {exercise['sets']}  **Reps:** {exercise['reps']}  **Rest:** {exercise['rest']}")
                st.write(f"**Explanation:** {exercise['explanation']}")
        else:
            st.write("No workout available for the selected day.")
    except Exception as e:
        st.write(f"Error: {str(e)}")

# Function to get user input from sidebar
def user_input_features():
    age = st.sidebar.slider("Age: ", 10, 100, 30)
    bmi = st.sidebar.slider("BMI: ", 15, 40, 20)
    duration = st.sidebar.slider("Duration (min): ", 0, 35, 15)
    heart_rate = st.sidebar.slider("Heart Rate: ", 60, 130, 80)
    body_temp = st.sidebar.slider("Body Temperature (C): ", 36, 42, 38)
    gender_button = st.sidebar.radio("Gender: ", ("Male", "Female"))
    gender = 1 if gender_button == "Male" else 0

    data_model = {
        "Age": age,
        "BMI": bmi,
        "Duration": duration,
        "Heart_Rate": heart_rate,
        "Body_Temp": body_temp,
        "Gender_male": gender
    }

    features = pd.DataFrame(data_model, index=[0])
    return features

# Function to preprocess data and train the model
def train_model():
    calories = pd.read_csv("calories.csv")
    exercise = pd.read_csv("exercise.csv")
    
    exercise_df = exercise.merge(calories, on="User_ID")
    exercise_df.drop(columns="User_ID", inplace=True)
    
    exercise_train_data, exercise_test_data = train_test_split(exercise_df, test_size=0.2, random_state=1)

    # Add BMI column
    for data in [exercise_train_data, exercise_test_data]:
        data["BMI"] = data["Weight"] / ((data["Height"] / 100) ** 2)
        data["BMI"] = round(data["BMI"], 2)

    exercise_train_data = exercise_train_data[["Gender", "Age", "BMI", "Duration", "Heart_Rate", "Body_Temp", "Calories"]]
    exercise_test_data = exercise_test_data[["Gender", "Age", "BMI", "Duration", "Heart_Rate", "Body_Temp", "Calories"]]
    exercise_train_data = pd.get_dummies(exercise_train_data, drop_first=True)
    exercise_test_data = pd.get_dummies(exercise_test_data, drop_first=True)

    # Train RandomForest model
    X_train = exercise_train_data.drop("Calories", axis=1)
    y_train = exercise_train_data["Calories"]
    
    random_reg = RandomForestRegressor(n_estimators=1000, max_features=3, max_depth=6)
    random_reg.fit(X_train, y_train)
    
    return random_reg, X_train.columns

# Function to display the predicted calories
def predict_calories(model, user_data, feature_columns):
    # Ensure that user_data has the same columns as the training data (excluding 'Calories')
    user_data = user_data.reindex(columns=feature_columns, fill_value=0)
    
    # Remove 'Calories' column from user_data if it exists
    if 'Calories' in user_data.columns:
        user_data = user_data.drop('Calories', axis=1)
    
    prediction = model.predict(user_data)
    return prediction[0]

# Function to add attendance
def mark_attendance():
    user_name = st.text_input("Enter your name: ", "")
    session_date = st.date_input("Select Date: ")
    attendance = st.radio("Attendance Status: ", ("Present", "Absent"))

    # Check if the user has entered their name
    if user_name and session_date:
        # Create a dictionary with attendance details
        attendance_data = {
            "Name": user_name,
            "Date": session_date,
            "Attendance": attendance
        }

        # Check if the attendance file exists, if not, create it
        try:
            attendance_df = pd.read_csv("attendance.csv")
        except FileNotFoundError:
            attendance_df = pd.DataFrame(columns=["Name", "Date", "Attendance"])

        # Convert the new attendance data into a DataFrame
        attendance_df_new = pd.DataFrame([attendance_data])

        # Concatenate the new attendance data with the existing DataFrame
        attendance_df = pd.concat([attendance_df, attendance_df_new], ignore_index=True)

        # Save the updated attendance data to the CSV file
        attendance_df.to_csv("attendance.csv", index=False)

        st.success(f"Attendance marked as {attendance} for {user_name} on {session_date}.")

    else:
        st.warning("Please enter your name and select a date.")

# Function to display the attendance record
def display_attendance():
    try:
        # Load the attendance data from the CSV file
        attendance_df = pd.read_csv("attendance.csv")
        st.write("### Attendance Record:")
        st.dataframe(attendance_df)
    except FileNotFoundError:
        st.write("No attendance data available.")

# AI-Powered Workout & Meal Suggestions
def ai_workout_meal_suggestions():
    st.sidebar.header("🎯 AI Workout & Meal Suggestions")
    
    # User Inputs
    age = st.sidebar.slider("Select Your Age", 10, 80, 25)
    bmi = st.sidebar.slider("Select Your BMI", 15, 40, 22)
    goal = st.sidebar.radio("Select Your Goal", ["Lose Weight", "Maintain Fitness", "Gain Muscle"])
    experience = st.sidebar.selectbox("Select Your Experience Level", ["Beginner", "Intermediate", "Advanced"])

    # AI Workout Recommendation Logic
    def recommend_workout():
        if goal == "Lose Weight":
            if experience == "Beginner":
                return "💪 **Workout Plan:** 30-minute brisk walk + Bodyweight HIIT (Jump Squats, Push-Ups, Burpees)."
            elif experience == "Intermediate":
                return "🔥 **Workout Plan:** 40-minute cardio (running, cycling) + Strength Training (Deadlifts, Lunges, Bench Press)."
            else:
                return "🏋️ **Workout Plan:** 60-minute advanced HIIT + Weight Training (Kettlebell Swings, Heavy Squats)."
        elif goal == "Maintain Fitness":
            return "🏃 **Workout Plan:** 45-minute mixed workout (Cardio + Strength) focusing on flexibility and endurance."
        else:
            return "🏋️‍♂️ **Workout Plan:** Strength-based (Squats, Bench Press, Deadlifts, Overhead Press) with progressive overload."

    # AI Meal Recommendation Logic
    def recommend_meal():
        if goal == "Lose Weight":
            return "🥗 **Meal Plan:** High protein, low-carb (Grilled chicken, broccoli, quinoa, Greek yogurt, nuts)."
        elif goal == "Maintain Fitness":
            return "🍏 **Meal Plan:** Balanced diet (Lean protein, whole grains, vegetables, healthy fats)."
        else:
            return "🍗 **Meal Plan:** High-calorie, high-protein (Steak, rice, eggs, peanut butter, protein shakes)."

    # Display AI Recommendations
    st.subheader("🏋️ AI Workout Recommendation")
    st.write(recommend_workout())

    st.subheader("🍽️ AI Meal Plan Recommendation")
    st.write(recommend_meal())

# Call the function in your main app
ai_workout_meal_suggestions()

# Main script execution
def main():
    st.title("Personal Fitness Tracker")
    st.sidebar.header("User Input Parameters")

    user_data = user_input_features()
    
    st.write("---")
    st.header("Your Parameters:")
    st.write(user_data)
    
    st.write("---")
    st.header("Prediction: ")
    model, feature_columns = train_model()
    prediction = predict_calories(model, user_data, feature_columns)
    
    st.write(f"Predicted Calories Burned: {round(prediction, 2)} kilocalories")

    # Attendance feature
    st.write("---")
    st.header("Attendance Tracker")
    mark_attendance()  # Attendance form
    display_attendance()  # Display the attendance records

# Run the application
if __name__ == "__main__":
    main()
import streamlit as st

# Function to display the meal plan for a given day
def get_diet_plan(day):
    # Balanced Monthly Diet Plan
    diet_plan = {
        1: {
            "Breakfast": "Oatmeal with chia seeds, almond butter, and mixed berries.",
            "Lunch": "Grilled chicken breast, quinoa, steamed broccoli, and a side salad (with olive oil dressing).",
            "Dinner": "Salmon fillet with roasted sweet potatoes and sautéed spinach."
        },
        2: {
            "Breakfast": "Whole grain toast with avocado, poached eggs, and cherry tomatoes.",
            "Lunch": "Lentil soup with whole wheat crackers and a mixed greens salad.",
            "Dinner": "Stir-fried tofu with brown rice and mixed vegetables (bell peppers, carrots, broccoli)."
        },
        3: {
            "Breakfast": "Greek yogurt with honey, walnuts, and sliced banana.",
            "Lunch": "Turkey and avocado wrap with whole wheat tortilla and a side of mixed fruit.",
            "Dinner": "Grilled shrimp with quinoa, asparagus, and a side of roasted zucchini."
        },
        4: {
            "Breakfast": "Scrambled eggs with spinach, tomatoes, and a slice of whole-grain toast.",
            "Lunch": "Chicken Caesar salad (with low-fat dressing, grilled chicken, romaine lettuce, and a sprinkle of parmesan).",
            "Dinner": "Beef stir-fry with broccoli, snap peas, and brown rice."
        },
        5: {
            "Breakfast": "Smoothie with spinach, banana, protein powder, almond milk, and peanut butter.",
            "Lunch": "Baked chicken with roasted potatoes and sautéed green beans.",
            "Dinner": "Grilled turkey burger with a side salad (mixed greens, cucumber, avocado)."
        },
        6: {
            "Breakfast": "Whole grain pancakes with fresh strawberries and a drizzle of maple syrup.",
            "Lunch": "Quinoa salad with chickpeas, cucumber, tomatoes, and olive oil dressing.",
            "Dinner": "Grilled tilapia with mashed cauliflower and steamed asparagus."
        },
        7: {
            "Breakfast": "Overnight oats with almond milk, chia seeds, and blueberries.",
            "Lunch": "Grilled chicken and vegetable kabobs with a side of couscous.",
            "Dinner": "Vegetarian chili with kidney beans, tomatoes, and a side of brown rice."
        },
        8: {
            "Breakfast": "Scrambled eggs with diced bell peppers, onions, and mushrooms.",
            "Lunch": "Tuna salad with mixed greens, cherry tomatoes, and a lemon vinaigrette dressing.",
            "Dinner": "Baked salmon with quinoa and steamed broccoli."
        },
        9: {
            "Breakfast": "Whole grain waffles with fresh fruit and a dollop of Greek yogurt.",
            "Lunch": "Grilled chicken sandwich with whole wheat bread, avocado, and a side salad.",
            "Dinner": "Spaghetti with whole wheat pasta, marinara sauce, and grilled chicken."
        },
        10: {
            "Breakfast": "Chia pudding with almond milk, topped with nuts and berries.",
            "Lunch": "Shrimp and avocado salad with mixed greens and a lime dressing.",
            "Dinner": "Stir-fried tofu with mixed veggies and brown rice."
        },
         11: {
            "Breakfast": "Smoothie bowl with protein powder, spinach, banana, almond butter, and chia seeds.",
            "Lunch": "Chicken breast with roasted sweet potatoes and steamed green beans.",
            "Dinner": "Beef stew with carrots, potatoes, and peas."
        },
        12: {
            "Breakfast": "Greek yogurt with granola, strawberries, and a drizzle of honey.",
            "Lunch": "Quinoa and chickpea salad with cucumber, tomatoes, and feta cheese.",
            "Dinner": "Grilled chicken with roasted Brussels sprouts and quinoa."
        },
        13: {
            "Breakfast": "Avocado toast with poached eggs and a side of mixed fruit.",
            "Lunch": "Turkey and spinach wrap with whole wheat tortilla and a side of carrot sticks.",
            "Dinner": "Baked cod with mashed sweet potatoes and sautéed kale."
        },
        14: {
            "Breakfast": "Smoothie with protein powder, kale, pineapple, and almond milk.",
            "Lunch": "Tuna salad with mixed greens, cucumber, and olive oil dressing.",
            "Dinner": "Grilled shrimp with quinoa and a side of roasted Brussels sprouts."
        },
        15: {
            "Breakfast": "Scrambled eggs with avocado and a side of whole-grain toast.",
            "Lunch": "Lentil and vegetable stew with whole-grain crackers.",
            "Dinner": "Chicken stir-fry with brown rice and mixed vegetables."
        },
        16: {
            "Breakfast": "Oatmeal with almond milk, chia seeds, and blueberries.",
            "Lunch": "Grilled chicken breast with roasted sweet potatoes and steamed broccoli.",
            "Dinner": "Spaghetti squash with marinara sauce and turkey meatballs."
        },
        17: {
            "Breakfast": "Whole grain toast with almond butter and banana slices.",
            "Lunch": "Chicken Caesar salad with light dressing and a sprinkle of parmesan cheese.",
            "Dinner": "Grilled salmon with quinoa and sautéed spinach."
        },
        18: {
            "Breakfast": "Smoothie with protein powder, spinach, strawberries, and almond milk.",
            "Lunch": "Turkey and avocado sandwich on whole wheat bread with a side of mixed fruit.",
            "Dinner": "Beef stir-fry with bell peppers, onions, and brown rice."
        },
        19: {
            "Breakfast": "Greek yogurt with chia seeds, almonds, and sliced peaches.",
            "Lunch": "Grilled chicken with roasted Brussels sprouts and quinoa.",
            "Dinner": "Stir-fried tofu with mixed veggies and brown rice."
        },
        20: {
            "Breakfast": "Scrambled eggs with spinach, tomatoes, and feta cheese.",
            "Lunch": "Tuna salad with mixed greens, cucumber, and olive oil dressing.",
            "Dinner": "Grilled chicken with roasted sweet potatoes and steamed asparagus."
        },
        21: {
            "Breakfast": "Whole grain pancakes with fresh blueberries and a drizzle of honey.",
            "Lunch": "Quinoa salad with chickpeas, cucumber, and feta cheese.",
            "Dinner": "Grilled shrimp with quinoa and steamed broccoli."
        },
        22: {
            "Breakfast": "Chia pudding with almond milk, topped with mixed berries.",
            "Lunch": "Chicken wrap with whole wheat tortilla, avocado, and lettuce.",
            "Dinner": "Grilled salmon with roasted sweet potatoes and spinach."
        },
        23: {
            "Breakfast": "Oatmeal with almond milk, chia seeds, and banana.",
            "Lunch": "Grilled chicken breast with quinoa and a side of steamed vegetables.",
            "Dinner": "Beef stew with carrots, potatoes, and peas."
        },
        24: {
            "Breakfast": "Smoothie with spinach, protein powder, almond milk, and strawberries.",
            "Lunch": "Shrimp and avocado salad with mixed greens and olive oil dressing.",
            "Dinner": "Stir-fried tofu with mixed vegetables and brown rice."
        },
        25: {
            "Breakfast": "Scrambled eggs with diced bell peppers and onions.",
            "Lunch": "Quinoa and vegetable salad with chickpeas.",
            "Dinner": "Grilled chicken with roasted Brussels sprouts and sweet potatoes."
        },
        26: {
            "Breakfast": "Whole grain toast with avocado and poached eggs.",
            "Lunch": "Tuna salad with mixed greens and cucumber.",
            "Dinner": "Grilled salmon with quinoa and steamed broccoli."
        },
        27: {
            "Breakfast": "Greek yogurt with granola, nuts, and fresh strawberries.",
            "Lunch": "Chicken breast with roasted vegetables and a side of couscous.",
            "Dinner": "Beef stir-fry with brown rice and mixed vegetables."
        },
        28: {
            "Breakfast": "Smoothie bowl with spinach, banana, protein powder, and almond milk.",
            "Lunch": "Grilled turkey burger with a side of mixed greens salad.",
            "Dinner": "Stir-fried tofu with quinoa and vegetables."
        },
        29: {
            "Breakfast": "Oatmeal with chia seeds, banana, and almonds.",
            "Lunch": "Quinoa salad with cucumber, tomatoes, and chickpeas.",
            "Dinner": "Grilled shrimp with roasted sweet potatoes and steamed asparagus."
        },
        30: {
            "Breakfast": "Scrambled eggs with spinach and whole-grain toast.",
            "Lunch": "Chicken Caesar salad with grilled chicken and light dressing.",
            "Dinner": "Baked cod with quinoa and sautéed kale."
        }
    }

    # Check if the selected day is within range
    if day in diet_plan:
        return diet_plan[day]
    else:
        return {
            "Breakfast": "No meal plan available for today.",
            "Lunch": "No meal plan available for today.",
            "Dinner": "No meal plan available for today."
        }

# Function to display the diet plan
def display_diet_plan():
    # Ask user for the day of the month
    day = st.sidebar.slider("Select Day of the Month", 1, 30, 1)
    
    # Get the meal plan for the selected day
    meal_plan = get_diet_plan(day)
    
    # Display the meal plan
    st.header(f"Meal Plan for Day {day}")
    st.subheader("Breakfast")
    st.write(meal_plan["Breakfast"])
    
    st.subheader("Lunch")
    st.write(meal_plan["Lunch"])
    
    st.subheader("Dinner")
    st.write(meal_plan["Dinner"])

# Main script execution
def main():
    st.title("Personal Fitness Tracker ")
    st.title(" Daily Diet Plan")
    st.sidebar.header("Select Day to View Meal Plan")
    
    display_diet_plan()

# Run the application
if __name__ == "__main__":
    main()